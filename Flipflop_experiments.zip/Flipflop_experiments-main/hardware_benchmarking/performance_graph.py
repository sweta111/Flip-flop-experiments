from matplotlib import pyplot as plt
plt.rcParams.update({'font.size': 22})
